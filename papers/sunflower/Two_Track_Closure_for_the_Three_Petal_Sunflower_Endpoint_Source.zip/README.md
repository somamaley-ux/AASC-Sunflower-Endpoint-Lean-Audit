# Two-Track Sunflower Closure manuscript

This is a replacement manuscript, not an edit of the earlier residual-separator paper.

The proof has one dependency crossing:

1. finite combinatorics reduces a dense high-rank countercase to an oversized canonical support fibre;
2. the manuscript verifies four kernel-neutral adequacy conditions, invokes the named Kernel Import Theorem, and uses its local K1-K13 packet plus denial/strict-weakening exhaustion to exclude that fibre;
3. the verified Lean transfer converts the fibre bound into the endpoint bound.

Build with `latexmk -pdf main.tex` or `tectonic main.tex` from this directory.

The theorem is stated over every non-degenerate determinate finite-family
regime. AASC is not an optional qualifier: it identifies the minimal necessity
conditions for the determinate identity, comparison, transformation,
standing-bearing use, reference, and endpoint already used by the proof. The
final closeout therefore depends on the kernel without becoming conditional on
an elective interpretive framework.

The Lean companion now imports the standalone kernel mechanization at a pinned
commit and instantiates its construction regime, fixed-domain closure,
uniqueness, no-derivation-below, and no-lower-generator theorems on the
Sunflower endpoint. `ImportedManuscriptKernelGovernedPopulationTheorem`
separately represents Theorem 6.2's target-specific finite profile/role/slot
population conclusion. Lean then derives the fibre bound, constructs the
high-rank source, transfers to a genuine sunflower, and proves the endpoint.
No additional support-fibre source remains. The exact-strength equivalence
records that the population proof object is endpoint-strength. The public
v0.2.0 repository contains 28 dependency modules, including 23 V2 modules,
plus one terminal root import. What is absent is an AASC-free conventional
analogue and an independent Lean reconstruction of the target-specific
population proof.
