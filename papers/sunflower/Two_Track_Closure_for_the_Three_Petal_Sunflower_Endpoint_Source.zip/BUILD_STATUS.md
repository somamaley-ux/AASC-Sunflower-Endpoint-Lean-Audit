# Verified build status

Date: 2026-07-14

## Manuscript

- Tectonic 0.16.9 build: passed
- PDF length: 31 pages
- Bibliography and cross-reference passes: completed
- Visual QA: all 31 rendered pages inspected; no clipping, overlap, or blank pages
- Serious overfull boxes: none

## Lean companion

- Audit command: powershell -ExecutionPolicy Bypass -File scripts/check-sunflower-a-plus-audit.ps1
- Result: passed
- Public proof spine: 28 transitive dependency modules, including 23 V2 modules,
  plus one terminal root
- Pinned mechanized-kernel dependency: commit
  `8b51f035f86f781e5eeb18cbaef8b46e74ed4924`
- Build jobs: 1050
- Focused axiom anchors: 25
- Placeholder and escape scan: passed
- Kernel import and bridge: axiom-free
- Reported axioms on remaining audited anchors: propext, Classical.choice,
  Quot.sound

## Claim boundary

The theorem closes for every non-degenerate determinate finite-family regime.
AASC names the necessary governance of the determinate objects and operations
already quantified; it is not an optional property of selected families. The
ultimate proof invokes the Kernel Import Theorem after verifying four neutral
adequacy conditions. Its K1--K13 consequences and denial/strict-weakening
exhaustion are part of the proof, not commentary.

The Lean v0.2.0 repository matches this dependency order. Its root imports only
`SunflowerAASC.V2.ManuscriptKernelTransfer`. The release imports the standalone
mechanized kernel and constructs its fixed-domain certificate on the concrete
endpoint. It then types manuscript Theorem 6.2 at its finite
profile/role/slot conclusion, applies local activation and denial exhaustion,
derives the canonical fibre bound, constructs the rank-uniform source,
transfers to a genuine sunflower, and proves the base-8384512 endpoint. The
remaining modular boundary is exactly the manuscript population theorem; there
is no additional Lean-only support-fibre premise. No AASC-free conventional
analogue is claimed for the crossing.
